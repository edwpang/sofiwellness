<?php
/* $Id: index.php,v 1.1 2008/01/22 04:20:03 steven Exp $
 * Created on 2007-2-23, 23:12:14
 * @author steven
 */

require_once '../php/Application/home_index.php';
?>