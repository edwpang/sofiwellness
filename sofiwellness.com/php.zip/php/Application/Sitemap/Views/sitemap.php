<?php
/*
 * $Id:$
 * FILE:sitemap.php
 * CREATE: Mar 7, 2013
 * BY: Edward Pang
 *  
 * NOTE:
 * 
 */

echo 'http://www.sofiwellness.com/home';
echo 'http://www.sofiwellness.com/service';
echo 'http://www.sofiwellness.com/aboutus';
echo 'http://www.sofiwellness.com/appointment';
echo 'http://www.sofiwellness.com/contact';

?>