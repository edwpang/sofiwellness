
<div id="container" style="width:1280px;align:center;">
<div id="content" style="width:100%;align:center; ">
</div>
</div>
