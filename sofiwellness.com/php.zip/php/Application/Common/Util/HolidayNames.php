<?php
/*
 * $Id:$
 * FILE:HolidayNames.php
 * CREATE: Jun 2, 2010
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
class HolidayNames
{
	const NEW_YEARS = 'New Years Day';
	const FAMILY_DAY = 'Family Day';
	const GOOD_FRIDAY = 'Good Friday';	
	const VICTORIA_DAY = 'Victoria Day';	
	const CANADA_DAY = 'Canada Day';	
	const CIVIC = 'Civic Holiday';		
	const LABOR = 'Labour Day';	
	const THANKSGIVING = 'Thanksgiving Day';
	const CHRISTMAS = 'Christmas';
	const BOXING_DAY = 'Boxing Day';
}
?>