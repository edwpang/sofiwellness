<?php
/*
 * $Id:$
 * FILE:HomeInclude.php
 * CREATE: May 14, 2010
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
require_once 'HomeConstants.php';

require_once  APP_COMMON_DIR . '/CommonInclude.php';



Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_View');
?>