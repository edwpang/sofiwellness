<?php
/*
 * $Id:$
 * FILE:HomeConstants.php
 * CREATE: May 14, 2010
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
define('HOME_MODULE_VIEWS',       APP_ROOT . '/Application/Home/Views');
define('HOME_MODULE_MODELS',      APP_ROOT . '/Application/Home/Models');
define('HOME_MODULE_CONTROLLERS', APP_ROOT . '/Application/Home/Controllers');

?>