<?php
/*
 * $Id:$
 * FILE:UserInclude.php
 * CREATE: Jun 25, 2010
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
require_once  APP_COMMON_DIR . '/CommonInclude.php';
require_once  APP_USERMGMT_DIR .'/UserMgmtInclude.php';

define('USER_MODULE_VIEWS',       APP_USER_DIR . '/Views');
define('USER_MODULE_MODELS',      APP_USER_DIR . '/Models');
define('USER_MODULE_CONTROLLERS', APP_USER_DIR . '/Controllers');

?>