<?php
/*
 * $Id:$
 * FILE:AboutConstants.php
 * CREATE: Jun 21, 2010
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
define('ABOUT_MODULE_VIEWS',       APP_ROOT . '/Application/About/Views');
define('ABOUT_MODULE_MODELS',      APP_ROOT . '/Application/About/Models');
define('ABOUT_MODULE_CONTROLLERS', APP_ROOT . '/Application/About/Controllers');

?>