<?php
/*
 * $Id:$
 * FILE:AbountInclude.php
 * CREATE: Jun 21, 2010
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
require_once 'AboutConstants.php';

require_once  APP_COMMON_DIR . '/CommonInclude.php';



Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_View');
?>