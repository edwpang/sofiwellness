<?php
/*
 * $Id: ReminderConstants.php,v 1.1 2009/02/26 19:55:58 gorsen Exp $
 * FILE:ReminderConstants.php
 * CREATE: Feb 17, 2009
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
class AppointmentConstants
{
	const DUE_DATE_LOCAL ='due_date_local';
	const DUE_DATE = 'due_date';
	const DATE = 'date';
	const TIME = 'time';
}
?>