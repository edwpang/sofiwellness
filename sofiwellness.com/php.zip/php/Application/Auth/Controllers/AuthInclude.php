<?php
/*
 * $Id:$
 * FILE:AuthInclude.php
 * CREATE: May 16, 2010
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
require_once  APP_COMMON_DIR . '/CommonInclude.php';

define('AUTH_MODULE_VIEWS',       APP_AUTH_DIR . '/Views');
define('AUTH_MODULE_MODELS',      APP_AUTH_DIR . '/Models');
define('AUTH_MODULE_CONTROLLERS', APP_AUTH_DIR . '/Controllers');
?>