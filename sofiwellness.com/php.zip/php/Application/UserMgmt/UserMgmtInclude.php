<?php
/*
 * Created on Sep 14, 2007
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 
 


require_once  APP_USERMGMT_DIR . '/UserManager.php';
require_once  APP_USERMGMT_DIR . '/UserInfo.php';
require_once  APP_USERMGMT_DIR . '/AccountTypes.php';
require_once  APP_USERMGMT_DIR . '/UserInfoDbAccessor.php';
require_once  APP_USERMGMT_DIR . '/RoleNames.php';

 
?>
