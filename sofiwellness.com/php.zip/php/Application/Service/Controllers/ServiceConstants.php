<?php
/*
 * $Id:$
 * FILE:ServiceConstants.php
 * CREATE: Jun 18, 2010
 * BY:guosheng
 *  
 * NOTE:
 * 
 */
define('SERVICE_MODULE_VIEWS',       APP_ROOT . '/Application/Service/Views');
define('SERVICE_MODULE_MODELS',      APP_ROOT . '/Application/Service/Models');
define('SERVICE_MODULE_CONTROLLERS', APP_ROOT . '/Application/Service/Controllers');

?>